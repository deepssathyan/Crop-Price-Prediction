import io
import itertools
from datetime import datetime

from flask import Blueprint, render_template, Response, make_response
from flask_login import login_required, current_user

from .models import User, Reports, Invoice

report = Blueprint('reportsBlueprint', __name__)


@report.route('/reports/<uid>')
@login_required
def all_reports(uid):
    user = User.query.get(uid)
    # if user.category == 'farmer':
    #     reports = Reports.query.filter_by(farmerID=uid)
    # else:
    #     reports = Reports.query.filter_by(buyerID=uid)

    invoices = Invoice.query.all()
    n = len(invoices)
    grouped_invoice = []
    if n > 0:
        current_cart_id = invoices[0].cartID
        i = 0
        items = []

        while i <= n:
            if i < n and invoices[i].cartID == current_cart_id:
                items.append(invoices[i])
                i += 1
            else:
                grouped_invoice.append(items)
                items = []
                if i == n:
                    break
                current_cart_id = invoices[i].cartID

    inv = []
    for i in grouped_invoice:
        if user.category == 'farmer':
            invo = []
            for invoic in i:
                if invoic.report.farmerID == user.id:
                    invo.append(invoic)
            if(invo):
                inv.append(invo)
        else:
            if i[0].report.buyerID == user.id:
                inv.append(i)

    inv.reverse()

    # reports = reports.order_by(Reports.id.desc()).all()
    return render_template('reports.html', user=current_user, invoices=inv)  # reports=reports,


@report.route('/report/<rid>')
@login_required
def report_id(rid):
    user_report = Reports.query.get(rid)

    from reportlab.platypus import Table, TableStyle, SimpleDocTemplate, Paragraph, Spacer, Image
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle, TA_CENTER
    heading_style = getSampleStyleSheet()['Heading2']
    output = io.BytesIO()
    width, height = A4
    pdf = SimpleDocTemplate(output, title='Report')

    widgets = []

    file_name = f'{user_report.buyer.firstName}-{datetime.now()}.pdf'

    title_style1 = ParagraphStyle('Title1', fontSize=24, alignment=TA_CENTER, fontName='Helvetica-Bold')
    title_style2 = ParagraphStyle('Title1', fontSize=20, alignment=TA_CENTER, fontName='Helvetica-Bold')

    f = open('C:/Users/Balaji/Desktop/logo.jpg', 'rb')

    widgets.append(Image(f, width=50, height=50))
    widgets.append(Paragraph('Farmer Buyer portal', style=title_style1))
    widgets.append(Spacer(width=10, height=40))

    widgets.append(Paragraph('Invoice', style=title_style2))
    widgets.append(Spacer(width=10, height=30))

    # Product Description
    widgets.append(Paragraph('Product Description:', style=heading_style))
    widgets.append(Spacer(width=10, height=20))

    data = [['Product', 'Price', 'Quantity', 'Price per KG'],
            [user_report.product.name, f'INR {user_report.product.price}', f'{user_report.quantity} kg',
             f'{user_report.product.price} / kg']]
    # t = Table(data, colWidths=120, rowHeights=30)
    t = Table(data, colWidths=(width / 4) - 40, rowHeights=30)
    t.setStyle(TableStyle([('BACKGROUND', (0, 0), (3, 0), colors.darkgray),
                           ('FONTNAME', (0, 0), (3, 0), 'Helvetica-Bold'),
                           ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
                           ('INNERGRID', (0, 0), (-1, -1), 0.25, colors.black),
                           ('BOX', (0, 0), (-1, -1), 0.25, colors.black)]))
    widgets.append(t)
    widgets.append(Spacer(width=10, height=10))

    # Buyer Details
    widgets.append(Paragraph('Buyer Details:', style=heading_style))
    widgets.append(Spacer(width=10, height=20))

    data = [['Name', 'Phone Number', 'Email'],
            [f'{user_report.buyer.firstName} {user_report.buyer.lastName}', f'{user_report.buyer.phoneNumber}',
             f'{user_report.buyer.email}']]
    t = Table(data, colWidths=(width / 3) - 50, rowHeights=30)
    t.setStyle(TableStyle([('BACKGROUND', (0, 0), (-1, 0), colors.darkgray),
                           ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                           ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
                           ('INNERGRID', (0, 0), (-1, -1), 0.25, colors.black),
                           ('BOX', (0, 0), (-1, -1), 0.25, colors.black)]))

    widgets.append(t)
    widgets.append(Spacer(width=10, height=10))

    # Farmer Details
    widgets.append(Paragraph('Seller Details:', style=heading_style))
    widgets.append(Spacer(width=10, height=20))

    data = [['Name', 'Phone Number', 'Email'],
            [f'{user_report.farmer.firstName} {user_report.farmer.lastName}', f'{user_report.farmer.phoneNumber}',
             f'{user_report.farmer.email}']]
    t = Table(data, colWidths=(width / 3) - 50, rowHeights=30)
    t.setStyle(TableStyle([('BACKGROUND', (0, 0), (-1, 0), colors.darkgray),
                           ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                           ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
                           ('INNERGRID', (0, 0), (-1, -1), 0.25, colors.black),
                           ('BOX', (0, 0), (-1, -1), 0.25, colors.black)]))

    widgets.append(t)
    widgets.append(Spacer(width=10, height=10))

    pdf.build(widgets)
    f.close()
    pdf_out = output.getvalue()
    output.close()

    response = make_response(pdf_out)
    response.headers['Content-Disposition'] = f"inline; filename={file_name}"
    response.mimetype = 'application/pdf'
    return response


@report.route('/reports/<uid>/download')
@login_required
def download_report(uid):
    user = User.query.get(uid)
    if user.category == 'farmer':
        reports = Reports.query.filter_by(farmerID=uid)
    else:
        reports = Reports.query.filter_by(buyerID=uid)
    reports = reports.order_by(Reports.id.asc()).all()

    import xlwt

    now = datetime.now()
    filename = f'{current_user.firstName}_{now}.xls'

    output = io.BytesIO()

    workbook = xlwt.Workbook()
    sh = workbook.add_sheet('Report')

    col_width = 256 * 25
    try:
        for i in itertools.count():
            sh.col(i).width = col_width
    except ValueError:
        pass

    font = xlwt.Font()  # Create the Font
    font.name = 'Times New Roman'
    font.height = 250
    style = xlwt.XFStyle()  # Create the Style
    style.font = font  # Apply the Font to the Style

    sh.write(0, 0, 'Date', style)
    sh.write(0, 1, 'Customer Name', style)
    sh.write(0, 2, 'Customer Mobile', style)
    sh.write(0, 3, 'Seller Name', style)
    sh.write(0, 4, 'Seller Mobile', style)
    sh.write(0, 5, 'Product Name', style)
    sh.write(0, 6, 'Quantity (in kg)', style)
    sh.write(0, 7, 'Price (in \u20B9)', style)

    date_format = xlwt.XFStyle()
    date_format.num_format_str = 'dd/mm/yyyy'
    date_format.font = font

    i = 0
    for report in reports:
        sh.write(i + 1, 0, report.date, date_format)
        sh.write(i + 1, 1, report.buyer.firstName, style)
        sh.write(i + 1, 2, report.buyer.phoneNumber, style)
        sh.write(i + 1, 3, report.farmer.firstName, style)
        sh.write(i + 1, 4, report.farmer.phoneNumber, style)
        sh.write(i + 1, 5, report.product.name, style)
        sh.write(i + 1, 6, report.quantity, style)
        sh.write(i + 1, 7, report.price, style)
        i += 1

    workbook.save(output)
    output.seek(0)

    return Response(output, mimetype="application/ms-excel",
                    headers={"Content-Disposition": f"attachment;filename={filename}"})


@report.route('/report/test')
def test():
    from reportlab.platypus import Table, TableStyle, SimpleDocTemplate, Paragraph, Spacer, Image
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle, TA_CENTER
    heading_style = getSampleStyleSheet()['Heading2']
    output = io.BytesIO()
    width, height = A4
    pdf = SimpleDocTemplate(output, title='Report')

    widgets = []

    title_style1 = ParagraphStyle('Title1', fontSize=24, alignment=TA_CENTER, fontName='Helvetica-Bold')
    title_style2 = ParagraphStyle('Title1', fontSize=20, alignment=TA_CENTER, fontName='Helvetica-Bold')

    f = open('C:/Users/Balaji/Desktop/logo.jpg', 'rb')

    widgets.append(Image(f, width=50, height=50))
    widgets.append(Paragraph('Farmer Buyer portal', style=title_style1))
    widgets.append(Spacer(width=10, height=40))

    widgets.append(Paragraph('Invoice', style=title_style2))
    widgets.append(Spacer(width=10, height=30))

    # Product Description
    widgets.append(Paragraph('Product Description:', style=heading_style))
    widgets.append(Spacer(width=10, height=20))

    data = [['Product', 'Price', 'Quantity', 'Price per KG'],
            ['Potato', 'INR 700', '10 kg', '70 / kg']]
    # t = Table(data, colWidths=120, rowHeights=30)
    t = Table(data, colWidths=(width / 4) - 40, rowHeights=30)
    t.setStyle(TableStyle([('BACKGROUND', (0, 0), (3, 0), colors.darkgray),
                           ('FONTNAME', (0, 0), (3, 0), 'Helvetica-Bold'),
                           ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
                           ('INNERGRID', (0, 0), (-1, -1), 0.25, colors.black),
                           ('BOX', (0, 0), (-1, -1), 0.25, colors.black)]))
    widgets.append(t)
    widgets.append(Spacer(width=10, height=10))

    # Buyer Details
    widgets.append(Paragraph('Product Description:', style=heading_style))
    widgets.append(Spacer(width=10, height=20))

    data = [['Name', 'Phone Number', 'Email'],
            ['Deepthi S', '987654321', 'deepthi@gmail.com']]
    t = Table(data, colWidths=(width / 3) - 50, rowHeights=30)
    t.setStyle(TableStyle([('BACKGROUND', (0, 0), (-1, 0), colors.darkgray),
                           ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                           ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
                           ('INNERGRID', (0, 0), (-1, -1), 0.25, colors.black),
                           ('BOX', (0, 0), (-1, -1), 0.25, colors.black)]))

    widgets.append(t)
    widgets.append(Spacer(width=10, height=10))

    # Farmer Details
    widgets.append(Paragraph('Seller Details:', style=heading_style))
    widgets.append(Spacer(width=10, height=20))

    data = [['Name', 'Phone Number', 'Email'],
            ['Balaji S', '1234567890', 'balaji@gmail.com']]
    t = Table(data, colWidths=(width / 3) - 50, rowHeights=30)
    t.setStyle(TableStyle([('BACKGROUND', (0, 0), (-1, 0), colors.darkgray),
                           ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                           ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
                           ('INNERGRID', (0, 0), (-1, -1), 0.25, colors.black),
                           ('BOX', (0, 0), (-1, -1), 0.25, colors.black)]))

    widgets.append(t)
    widgets.append(Spacer(width=10, height=10))

    pdf.build(widgets)
    f.close()
    pdf_out = output.getvalue()
    output.close()

    response = make_response(pdf_out)
    response.headers['Content-Disposition'] = "inline; filename=hello.pdf"
    response.mimetype = 'application/pdf'
    return response


@report.route('/report-cart/<cid>')
@login_required
def report_cart_id(cid):
    cart_report = Invoice.query.filter_by(cartID=cid).all()

    from reportlab.platypus import Table, TableStyle, SimpleDocTemplate, Paragraph, Spacer, Image
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.enums import TA_CENTER, TA_RIGHT
    heading_style = getSampleStyleSheet()['Heading2']
    output = io.BytesIO()
    width, height = A4
    pdf = SimpleDocTemplate(output, title='Report')

    widgets = []

    file_name = f'{cart_report[0].report.buyer.firstName}-{datetime.now()}.pdf'

    title_style1 = ParagraphStyle('Title1', fontSize=24, alignment=TA_CENTER, fontName='Helvetica-Bold')
    title_style2 = ParagraphStyle('Title1', fontSize=20, alignment=TA_CENTER, fontName='Helvetica-Bold')
    paragraph_style = ParagraphStyle('Paragraph1', fontSize=11, alignment=TA_RIGHT)

    f = open('C:/Users/Balaji/Desktop/logo.jpg', 'rb')

    widgets.append(Image(f, width=50, height=50))
    widgets.append(Paragraph('Farmer Buyer portal', style=title_style1))
    widgets.append(Spacer(width=10, height=40))

    widgets.append(Paragraph('Invoice', style=title_style2))
    widgets.append(Spacer(width=10, height=40))

    widgets.append(Paragraph(f"Purchased on: {cart_report[0].report.date.strftime('%b %m %Y')}", style=paragraph_style))
    widgets.append(Spacer(width=10, height=10))

    # Product Description
    widgets.append(Paragraph('Product Description:', style=heading_style))
    widgets.append(Spacer(width=10, height=20))

    data = [['Product', 'Price', 'Quantity', 'Price per KG', 'Bought From']]

    for report in cart_report:
        data.append([report.report.product.name, f'INR {report.report.product.price}', f'{report.report.quantity} kg',
                     f'{report.report.product.price} / kg', report.report.farmer.firstName])

    # t = Table(data, colWidths=120, rowHeights=30)
    t = Table(data, colWidths=(width / 5) - 30, rowHeights=30)
    t.setStyle(TableStyle([('BACKGROUND', (0, 0), (4, 0), colors.darkgray),
                           ('FONTNAME', (0, 0), (4, 0), 'Helvetica-Bold'),
                           ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
                           ('INNERGRID', (0, 0), (-1, -1), 0.25, colors.black),
                           ('BOX', (0, 0), (-1, -1), 0.25, colors.black)]))
    widgets.append(t)
    widgets.append(Spacer(width=10, height=10))

    # Buyer Details
    widgets.append(Paragraph('Buyer Details:', style=heading_style))
    widgets.append(Spacer(width=10, height=20))

    data = [['Name', 'Phone Number', 'Email'],
            [f'{cart_report[0].report.buyer.firstName} {cart_report[0].report.buyer.lastName}',
             f'{cart_report[0].report.buyer.phoneNumber}',
             f'{cart_report[0].report.buyer.email}']]
    t = Table(data, colWidths=(width / 3) - 50, rowHeights=30)
    t.setStyle(TableStyle([('BACKGROUND', (0, 0), (-1, 0), colors.darkgray),
                           ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                           ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
                           ('INNERGRID', (0, 0), (-1, -1), 0.25, colors.black),
                           ('BOX', (0, 0), (-1, -1), 0.25, colors.black)]))

    widgets.append(t)
    widgets.append(Spacer(width=10, height=10))

    # Farmer Details
    widgets.append(Paragraph('Seller Details:', style=heading_style))
    widgets.append(Spacer(width=10, height=20))

    data = [['Name', 'Phone Number', 'Email']]

    sellers = {'name': [], 'mobile': [], 'email': []}

    for report in cart_report:
        name = f'{report.report.farmer.firstName} {report.report.farmer.lastName}'
        mobile = f'{report.report.farmer.phoneNumber}'
        email = f'{report.report.farmer.email}'

        if name not in sellers['name']:
            sellers['name'].append(name)
            sellers['mobile'].append(mobile)
            sellers['email'].append(email)

    for i in range(len(sellers['name'])):
        data.append([sellers['name'][i], sellers['mobile'][i], sellers['email'][i]])

    t = Table(data, colWidths=(width / 3) - 50, rowHeights=30)
    t.setStyle(TableStyle([('BACKGROUND', (0, 0), (-1, 0), colors.darkgray),
                           ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                           ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
                           ('INNERGRID', (0, 0), (-1, -1), 0.25, colors.black),
                           ('BOX', (0, 0), (-1, -1), 0.25, colors.black)]))

    widgets.append(t)
    widgets.append(Spacer(width=10, height=10))

    pdf.build(widgets)
    f.close()
    pdf_out = output.getvalue()
    output.close()

    response = make_response(pdf_out)
    response.headers['Content-Disposition'] = f"inline; filename={file_name}"
    response.mimetype = 'application/pdf'
    return response
