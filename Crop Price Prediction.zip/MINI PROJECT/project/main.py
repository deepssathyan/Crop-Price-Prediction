from flask import Blueprint, render_template, redirect, url_for
from flask_login import login_required, current_user

from . import db
from .models import Products

main = Blueprint('main', __name__)


@main.route('/')
def index():
    if current_user.is_authenticated:
        return redirect(url_for('main.dashboard'))
    return render_template('welcome.html')


@main.route('/dashboard')
@login_required
def dashboard():
    if current_user.category == 'farmer':
        products = Products.query.filter_by(createdByID=current_user.id)
    else:
        products = Products.query.order_by(Products.isAvailable.desc())

    products = products.filter_by(isDeleted=False).all()
    return render_template('dashboard.html', user=current_user, products=products)
# order_by(Products.date.desc())
