from flask import Blueprint, request, render_template, Response
from flask_login import login_required, current_user

import pickle
import numpy as np
import json
from datetime import datetime
import time
import random

from .custom_decorator import is_farmer

prediction = Blueprint('prediction', __name__)

linear = pickle.load(open('poly_model.pickle', 'rb'))
poly_regs = pickle.load(open('poly_feature.pickle', 'rb'))


@prediction.route('/price/predict', methods=['GET', 'POST'])
@is_farmer
@login_required
def predict():
    if request.method == 'GET':
        return render_template('pricePrediction.html', user=current_user)

    month, climate, demand = request.form.values()
    errors = []
    if month == '0':
        errors.append('Select a month from the list')
    if climate == '0':
        errors.append('Select a climate from the list')
    if demand:
        if float(demand) > 1 or float(demand) < 0:
            errors.append('Enter demand in the the range (0 to 1) ')
    else:
        errors.append('Enter a demand value')
    if len(errors) > 0:
        return render_template('pricePrediction.html', errors=errors, user=current_user)

    features = [float(x) for x in request.form.values()]
    data = np.array(features)

    predicted_price = linear.predict(poly_regs.fit_transform([data]))
    price = round(predicted_price[0])

    return render_template('pricePrediction.html', price=f'Predicted Price : ₹ {price}', user=current_user)


@prediction.route('/price-data')
def price_data():
    def find_price():
        features = [datetime.now().month, random.randint(1, 4), random.random()]
        data = np.array(features)
        predicted_price = linear.predict(poly_regs.fit_transform([data]))
        price = abs(predicted_price[0])

        while True:
            rand = random.uniform(0.9, 1.1)
            t_price = price * rand

            # while t_price > 7000 or t_price < 2000:
            #     if t_price > 7000:
            #         t_price /= 7000
            #
            #     if t_price < 2000:
            #         t_price *= 2000 / random.uniform(1, 2)

            json_data = json.dumps(
                {'time': datetime.now().strftime('%d-%m-%y %H:%M:%S'), 'price': t_price})
            yield f"data:{json_data}\n\n"
            time.sleep(1)

    return Response(find_price(), mimetype='text/event-stream')
