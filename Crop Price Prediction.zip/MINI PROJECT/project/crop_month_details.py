months = {
    'Jan': {'north': ['Brinjal'],
            'south': ['Lettuce', 'Spinach', 'Gourds', 'Melons', 'Radish', 'Carrot', 'Onion', 'Tomato', 'Okra',
                      'Brinjal',
                      'Bean']},

    'Feb': {
        'north': ['Applegourd', 'Bittergourd', 'Bottle gourd', 'Cucumber', 'French Beans', 'Okra', 'Sponge', 'Gourd',
                  'Watermelon', 'Spinach'],
        'south': ['Lettuce', 'Spinach', 'Gourds', 'Melons', 'Radish', 'Carrot', 'Onion', 'Tomato', 'Okra', 'Brinjal',
                  'Bean']},

    'Mar': {
        'north': ['Applegourd', 'Bittergourd', 'Bottle gourd', 'Cucumber', 'French Beans', 'Okra', 'Sponge', 'Gourd',
                  'Watermelon', 'Spinach'],
        'south': ['Amaranthus', 'Coriander', 'Gourds', 'Beans', 'Melons', 'Spinach', 'Okra']},

    'Apr': {'north': ['Capsicum'],
            'south': ['Onion', 'Amaranthus', 'Coriander', 'Gourds', 'Okra', 'Tomato', 'Chilli']},

    'May': {'north': ['Onion', 'Pepper', 'Brinjal'],
            'south': ['Okra', 'Onion', 'Chilli']},

    'Jun': {'north': ['All gourds', 'Brinjal', 'Cucumber', 'Cauliflower (Early)', 'Okra', 'Onion', 'Tomato', 'Pepper'],
            'south': ['All Gourds', 'Solanaeceae', 'Almost all vegetables']},

    'Jul': {'north': ['All gourds', 'Cucumber', 'Okra', 'Tomato'],
            'south': ['All Gourds', 'Solanaeceae', 'Almost all vegetables']},

    'Aug': {'north': ['Carrot', 'Cauliflower', 'Radish', 'Tomato'],
            'south': ['Carrot', 'Cauliflower', 'Beans', 'Beet'
                      ]},

    'Sep': {'north': ['Cabbage', 'Carrot', 'Cauliflower', 'Peas', 'Radish', 'Tomato', 'Lettuce'],
            'south': ['Cauliflower', 'Cucumber', 'Onion', 'Peas', 'Spinach']},

    'Oct': {'north': ['Beet', 'Brinjal', 'Cabbage', 'Cauliflower', 'Lettuce', 'Peas', 'Radish', 'Spinach', 'Turnip'],
            'south': ['Brinjal', 'Cabbage', 'Capsicum', 'Cucumber', 'Beans', 'Peas', 'Spinach', 'Turnip', 'Watermelon'
                      ]},

    'Nov': {'north': ['Turnip', 'Tomato', 'Radish', 'Pepper', 'Peas', 'Beet'],
            'south': ['Beet', 'Eggplant', 'Cabbage', 'Carrot', 'Beans', 'Lettuce', 'Melon', 'Okra', 'Turnip']},

    'Dec': {'north': ['Tomato'],
            'south': ['Lettuce', 'Pumpkin', 'Watermelon', 'Muskmelon', 'Ash gourd', 'Ridge gourd', 'Bitter gourd',
                      'Bottle gourd', 'Cucumber', 'Chilly', 'Cabbage']},

}
