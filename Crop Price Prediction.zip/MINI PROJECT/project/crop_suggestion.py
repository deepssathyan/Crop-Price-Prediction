from flask import Blueprint, request, render_template
from flask_login import login_required, current_user

from .custom_decorator import is_farmer

from .crop_month_details import months
import random

import pickle
import numpy as np

suggestion = Blueprint('suggestion', __name__)


@suggestion.route('/crop/suggest', methods=['GET', 'POST'])
@is_farmer
@login_required
def suggest():
    if request.method == 'GET':
        return render_template('cropSuggesstion.html', user=current_user)
    month, state = request.form.values()

    errors = []
    if month == '0':
        errors.append('Select a month from the list')
    if state == '0':
        errors.append('Select a climate from the list')

    if len(errors) > 0:
        return render_template('cropSuggesstion.html', errors=errors, user=current_user)

    crops = months[month][state]
    prices = {}

    linear = pickle.load(open('poly_model.pickle', 'rb'))
    poly_regs = pickle.load(open('poly_feature.pickle', 'rb'))

    for i in range(len(crops)):
        random.seed(i ** 2)
        month = random.randint(1, 12)
        climate = random.randint(1, 4)
        demand = random.random()
        features = [month, climate, demand]
        data = np.array(features)

        predicted_price = linear.predict(poly_regs.fit_transform([data]))
        prices[crops[i]] = (round(predicted_price[0]))

    return render_template('cropSuggesstion.html', user=current_user, crops=crops, prices=prices)
