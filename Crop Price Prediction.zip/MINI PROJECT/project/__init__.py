from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager

from flask_admin import Admin
from flask_admin.contrib.sqla import ModelView

# init SQLAlchemy so we can use it later in our models

db = SQLAlchemy()


def create_app():
    app = Flask(__name__)
    admin = Admin(app, 'Farmer Buyer Portal', template_mode='bootstrap3')

    app.config['FLASK_ADMIN_SWATCH'] = 'journal'
    app.config['SECRET_KEY'] = '9OLWxND4o83j4K4iuopO'
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///db.sqlite?check_same_thread=False'
    # app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql://root@localhost/miniproject?'
    # app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql+psycopg2://balaji:balaji@localhost:5432/miniproject'

    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    app.config['SQLALCHEMY_ECHO'] = True

    db.init_app(app)

    login_manager = LoginManager()
    login_manager.login_view = 'auth.login'
    login_manager.init_app(app)

    from .models import User as userModel
    from .models import Products as productsModel
    from .models import Reports as reportsModel
    from .models import Cart as cartModel
    from .models import Invoice as invoiceModel

    admin.add_view(ModelView(userModel, db.session))
    admin.add_view(ModelView(productsModel, db.session))
    admin.add_view(ModelView(reportsModel, db.session))
    admin.add_view(ModelView(cartModel, db.session))
    admin.add_view(ModelView(invoiceModel, db.session))

    @login_manager.user_loader
    def load_user(user_id):
        return userModel.query.get(int(user_id))

    from .auth import auth as auth_blueprint
    app.register_blueprint(auth_blueprint)

    from .main import main as main_blueprint
    app.register_blueprint(main_blueprint)

    from .predict import prediction as prediction_blueprint
    app.register_blueprint(prediction_blueprint)

    from .product import product as product_blueprint
    app.register_blueprint(product_blueprint)

    from .profile import profile as profile_blueprint
    app.register_blueprint(profile_blueprint)

    from .report import report as report_blueprint
    app.register_blueprint(report_blueprint)

    from .cart import cart as cart_blueprint
    app.register_blueprint(cart_blueprint)

    from .crop_suggestion import suggestion as suggestion_blueprint
    app.register_blueprint(suggestion_blueprint)

    return app
