from flask import Blueprint, request, render_template, redirect, url_for, flash
from flask_login import login_required, current_user

from .custom_decorator import is_buyer
from .models import Products, Cart, Reports, Invoice

from . import db

import uuid

cart = Blueprint('cartBlueprint', __name__)


@cart.route('/cart/<uid>')
@is_buyer
@login_required
def cart_page(uid):
    cart_items = Cart.query.filter_by(buyerID=uid).all()
    total = 0
    for item in cart_items:
        total += item.price
    return render_template('cart_products.html', user=current_user, items=cart_items, total_price=total)


@cart.route('/cart/delete/<id>')
@is_buyer
@login_required
def delete_cart_item(id):
    item = Cart.query.get(id)
    db.session.delete(item)
    db.session.commit()
    return redirect(url_for('cart.cart_page', uid=current_user.id))


@cart.route('/cart/add/<pid>', methods=['GET', 'POST'])
@is_buyer
@login_required
def add_cart(pid):
    prod = Products.query.get(pid)

    if request.method == 'GET':
        return render_template('addToCart.html', product=prod, user=current_user)

    quantity = float(request.form.get('quantity'))

    cart_items = Cart.query.filter_by(buyerID=current_user.id).all()

    for item in cart_items:
        if item.product.name == prod.name:
            item.quantity += quantity
            if item.quantity > prod.stock:
                item.quantity = prod.stock
                flash('You can\'t add more than available quantity in the cart', 'error')
                return redirect(url_for('main.dashboard'))
            break
    else:
        cart_item = Cart(
            productID=prod.id,
            quantity=quantity,
            price=quantity * prod.price,
            buyerID=current_user.id
        )
        db.session.add(cart_item)

    db.session.commit()
    return redirect(url_for('main.dashboard'))


@cart.route('/cart/checkout/<uid>', methods=['POST'])
@is_buyer
@login_required
def checkout(uid):
    cart_items = Cart.query.filter_by(buyerID=uid).all()

    cart_id = str(uuid.uuid4())

    for item in cart_items:
        if item.quantity > item.product.stock:
            continue

        if item.product.stock == item.quantity:
            item.product.isAvailable = False
        else:
            item.product.stock -= item.quantity

        report = Reports(
            farmerID=item.product.createdByID,
            buyerID=current_user.id,
            productID=item.product.id,
            quantity=item.quantity,
            price=item.price
        )
        db.session.add(report)
        db.session.flush()

        invoice = Invoice(
            cartID=cart_id,
            reportID=report.id
        )

        db.session.add(invoice)

        db.session.delete(item)

    db.session.commit()
    return redirect(url_for('main.dashboard'))


@cart.route('/cart/edit/<id>', methods=['POST'])
@is_buyer
@login_required
def edit_cart_item(id):
    item = Cart.query.get(id)
    quantity = float(request.form.get('quantity'))
    item.quantity = quantity
    item.price = quantity * item.product.price
    db.session.commit()
    return redirect(url_for('cart.cart_page', uid=current_user.id))
