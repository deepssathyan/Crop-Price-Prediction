from sqlalchemy.orm import relationship

from . import db
from flask_login import UserMixin
from datetime import datetime

img = 'https://us.123rf.com/450wm/pavelstasevich/pavelstasevich1811/pavelstasevich181101065/112815953-stock-vector-no' \
      '-image-available-icon-flat-vector.jpg?ver=6'


class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    firstName = db.Column(db.String(100), nullable=False)
    lastName = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(1000), nullable=False)
    password = db.Column(db.String(1000), nullable=False)
    category = db.Column(db.String(10), nullable=False)
    phoneNumber = db.Column(db.String(10), nullable=False)
    date = db.Column(db.DateTime, default=datetime.now())
    isDeleted = db.Column(db.Boolean, default=False)

    def __repr__(self):
        return f'<User {self.firstName} {self.lastName}>'


class Products(db.Model):
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    src = db.Column(db.String(200), default=img)
    name = db.Column(db.String(50), nullable=False)
    price = db.Column(db.Float(), nullable=False)
    stock = db.Column(db.Float(), nullable=False)
    isAvailable = db.Column(db.Boolean, nullable=False, default=True)
    createdByID = db.Column(db.Integer, db.ForeignKey('user.id'))
    date = db.Column(db.DateTime, default=datetime.now())
    createdBy = relationship("User", foreign_keys=[createdByID])
    isDeleted = db.Column(db.Boolean, default=False)

    def __repr__(self):
        return f'<Product {self.name}>'


class Reports(db.Model):
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    farmerID = db.Column(db.Integer, db.ForeignKey('user.id'))
    buyerID = db.Column(db.Integer, db.ForeignKey('user.id'))
    productID = db.Column(db.Integer, db.ForeignKey('products.id'))
    quantity = db.Column(db.Float(), nullable=False)
    price = db.Column(db.Float(), nullable=False)
    date = db.Column(db.DateTime, default=datetime.now())
    farmer = relationship("User", foreign_keys=[farmerID])
    buyer = relationship("User", foreign_keys=[buyerID])
    product = relationship("Products", foreign_keys=[productID])

    def __repr__(self):
        return f'<Report BF {self.farmer.firstName} BB {self.buyer.firstName}>'


class Cart(db.Model):
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    productID = db.Column(db.Integer, db.ForeignKey('products.id'))
    quantity = db.Column(db.Float(), nullable=False)
    price = db.Column(db.Float(), nullable=False)
    buyerID = db.Column(db.Integer, db.ForeignKey('user.id'))
    buyer = relationship("User", foreign_keys=[buyerID])
    product = relationship("Products", foreign_keys=[productID])

    def __repr__(self):
        return f'<Cart Buyer {self.buyer.firstName} Prod {self.product.name}>'


class Invoice(db.Model):
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    cartID = db.Column(db.String(256))
    reportID = db.Column(db.Integer, db.ForeignKey('reports.id'))
    report = relationship("Reports", foreign_keys=[reportID])

    def __repr__(self):
        return f'<Report ID {self.reportID}>'
