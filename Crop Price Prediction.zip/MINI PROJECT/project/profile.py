from flask import Blueprint, render_template, flash, redirect, url_for, request
from flask_login import login_required, current_user, logout_user
from werkzeug.security import generate_password_hash

from . import db
from .models import User, Products
profile = Blueprint('profile', __name__)


@profile.route('/profile')
@login_required
def profile_page():
    return render_template('profile.html', user=current_user)


@profile.route('/profile/delete/<uid>', methods=['POST'])
@login_required
def profile_delete(uid):
    logout_user()
    user = User.query.get(uid)
    products = Products.query.filter_by(createdByID=uid).all()
    user.isDeleted = True
    for product in products:
        product.isDeleted = True
    db.session.commit()
    flash('Your account have been deleted', 'error')
    return redirect(url_for('auth.login'))


@profile.route('/profile/update', methods=['GET', 'POST'])
@login_required
def profile_update():
    if request.method == 'GET':
        return render_template('edit.html', user=current_user)

    first_name = request.form.get('firstName')
    last_name = request.form.get('lastName')
    phone = request.form.get('phone')
    password = request.form.get('password')
    password2 = request.form.get('password2')

    user = User.query.filter_by(id=current_user.id).first()
    user.firstName = first_name
    user.lastName = last_name
    user.phoneNumber = phone

    if password:
        if password == password2:
            user.password = generate_password_hash(password, method='sha256')
            db.session.commit()
            flash('Your Password have been updated successfully', 'success_msg')
            return redirect(url_for('auth.logout'))
        else:
            flash('Passwords do not match', 'error')
            return redirect(url_for('profile.profile_update'))
    db.session.commit()
    return redirect(url_for('profile.profile_page'))
