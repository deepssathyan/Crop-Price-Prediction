from flask import Blueprint, render_template, redirect, url_for, request, flash
from flask_login import login_user, login_required, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from .models import User
from . import db

auth = Blueprint('auth', __name__)


@auth.route('/login')
def login():
    if current_user.is_authenticated:
        return redirect(url_for('main.dashboard'))
    return render_template('login.html')


@auth.route('/login', methods=['POST'])
def user_login():
    email = request.form.get('email')
    password = request.form.get('password')

    user = User.query.filter_by(email=email).filter_by(isDeleted=False).first()
    if not user:
        flash('This email is not registered', 'error')
        return redirect(url_for('auth.login'))

    if not check_password_hash(user.password, password):
        flash('Password is incorrect', 'error')
        return redirect(url_for('auth.login'))

    login_user(user)
    return redirect(url_for('main.dashboard'))


@auth.route('/register')
def register():
    if current_user.is_authenticated:
        return redirect(url_for('main.dashboard'))
    return render_template('register.html')


@auth.route('/register', methods=['POST'])
def register_user():
    first_name = request.form.get('firstName')
    last_name = request.form.get('lastName')
    email = request.form.get('email')
    password = request.form.get('password')
    password2 = request.form.get('password2')
    phone = request.form.get('phone')
    category = request.form.get('category')

    errors = []

    if not first_name or not email or not password or not password2 or not phone or not category:
        errors.append('Please enter all fields')

    if password != password2:
        errors.append('Passwords do not match')

    if len(password) < 6:
        errors.append('Password must be at least 6 characters')

    if len(phone) < 10:
        errors.append('Enter a valid Phone Number')

    user = User.query.filter_by(email=email).filter_by(isDeleted=False).first()
    if user:
        errors.append('Email address already exists')

    if errors:
        return render_template('register.html', errors=errors)

    new_user = User(
        firstName=first_name,
        lastName=last_name,
        email=email,
        password=generate_password_hash(password, method='sha256'),
        phoneNumber=phone,
        category=category
    )

    db.session.add(new_user)
    db.session.commit()

    flash('You are now registered and can log in', 'success_msg')
    return redirect(url_for('auth.login'))


@auth.route('/logout')
@login_required
def logout():
    logout_user()
    flash('You have been logged out successfully', 'success_msg')
    return redirect(url_for('auth.login'))
