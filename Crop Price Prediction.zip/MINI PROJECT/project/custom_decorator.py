from flask import render_template
from flask_login import current_user
from functools import wraps


def is_farmer(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if current_user.category != 'farmer':
            return render_template('error.html', user=current_user, no='no', error='Only Farmers can access this page')
        return f(*args, **kwargs)
    return decorated_function


def is_buyer(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if current_user.category != 'buyer':
            return render_template('error.html', user=current_user, no='no', error='Only Buyers can access this page')
        return f(*args, **kwargs)
    return decorated_function
