from flask_admin.contrib.sqla import ModelView

from .models import User, Products, Reports, Cart


class UserModelView(ModelView):
    column_searchable_list = (User.firstName, User.lastName, User.email)

    def __init__(self):
        self.can_export = True
        self.export_types = ['xls']
