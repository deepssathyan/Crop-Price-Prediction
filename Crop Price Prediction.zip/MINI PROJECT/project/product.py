from flask import Blueprint, request, render_template, flash, redirect, url_for
from flask_login import login_required, current_user

from . import db
from .custom_decorator import is_farmer, is_buyer
from .models import Products, Reports

from datetime import datetime
import os

product = Blueprint('product', __name__)

PRODUCTS_IMAGE_UPLOADS = 'C:\\Users\\Balaji\\Desktop\\MINI PROJECT\\project\\static\\images\\uploads\\products'
STATIC_IMAGE_UPLOADS = 'static\\images\\uploads\\products'
ALLOWED_EXTENSIONS = ['jpg', 'jpeg', 'png', 'tif']


@product.route('/product/add', methods=['GET', 'POST'])
@is_farmer
@login_required
def add_product():
    if request.method == 'GET':
        return render_template('addItem.html', user=current_user)
    name = request.form.get('product')
    price = request.form.get('price')
    stock = request.form.get('stock')

    if request.files['productImage']:
        image = request.files['productImage']

        ext = image.filename.rsplit('.', 1)[1].lower()

        if ext not in ALLOWED_EXTENSIONS:
            flash('You can upload only image files.', 'error')
            return redirect(url_for('product.add_product'))

        file_name = f'{current_user.id}_{name}_{datetime.now().date()}.{ext}'

        file_path = os.path.join(PRODUCTS_IMAGE_UPLOADS, file_name)
        image.save(file_path)

        src = os.path.join(STATIC_IMAGE_UPLOADS, file_name)

    else:
        src = os.path.join(url_for('static', filename='images/default_product_image.jpg'))

    product = Products.query.filter_by(name=name).filter_by(price=price).filter_by(isDeleted=False).first()

    print(src)

    if product and product.createdByID == current_user.id and not product.isDeleted:
        product.stock += float(stock)
        product.isAvailable = True
        flash('Product have been updated', 'success_msg')
    else:
        new_product = Products(
            name=name,
            price=price,
            stock=stock,
            createdByID=current_user.id,
            src=src
        )
        db.session.add(new_product)
        flash('Product have been added', 'success_msg')

    db.session.commit()

    return redirect(url_for('main.dashboard'))


@product.route('/product/buy/<pid>', methods=['GET', 'POST'])
@is_buyer
@login_required
def product_buy(pid):
    prod = Products.query.get(pid)
    if request.method == 'GET':
        return render_template('buyItem.html', product=prod, user=current_user)

    quantity = float(request.form.get('quantity'))

    if prod.stock == quantity:
        prod.isAvailable = False
        prod.stock = 0
    else:
        prod.stock -= quantity

    report = Reports(
        farmerID=prod.createdByID,
        buyerID=current_user.id,
        productID=prod.id,
        quantity=quantity,
        price=quantity * prod.price
    )

    db.session.add(report)
    db.session.commit()
    return redirect(url_for('main.dashboard'))


@product.route('/product/edit/<pid>', methods=['GET', 'POST'])
@is_farmer
@login_required
def product_edit(pid):
    prod = Products.query.get(pid)
    if request.method == 'GET':
        return render_template('editItem.html', product=prod, user=current_user)

    price = request.form.get('price')
    stock = request.form.get('stock')

    prod.stock = stock
    prod.price = price
    prod.isAvailable = True if float(stock) > 0 else False
    db.session.commit()
    return redirect(url_for('main.dashboard'))


@product.route('/product/delete/<id>', methods=['POST'])
@is_farmer
@login_required
def product_delete(id):
    prod = Products.query.get(id)
    prod.isDeleted = True
    db.session.commit()
    return redirect(url_for('main.dashboard'))
