import pandas as pd
import numpy as np
from sklearn.svm import SVR
from sklearn.model_selection import train_test_split
import pickle

crop_name = 'Sugarcane'
weather = ['Average', 'Bad', 'Good', 'Great']
month = ['Jan', 'Feb', 'Mar', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']

data = pd.read_csv('data_set.csv')
data = data[['month', 'climate', 'demand', 'price']]

to_predict = 'price'

X = np.array(data.drop(to_predict, axis=1))
y = np.array(data[to_predict])

x_train, x_test, y_train, y_test = train_test_split(X, y, test_size=0.3)

best = 0
for i in range(1, 50):
    x_train, x_test, y_train, y_test = train_test_split(X, y, test_size=0.3)
    svr = SVR(kernel='rbf', epsilon=1.0, degree=3)

    svr.fit(x_train, y_train)
    acc = svr.score(x_test, y_test)
    print(f'Accuracy : {acc}')

    if acc > best:
        with open("svr_model.pickle", "wb") as f:
            pickle.dump(svr, f)
        best = acc

svr = pickle.load(open('svr_model.pickle', 'rb'))

print(best)
prediction = svr.predict([[1, 1, 0.6]])
print(round(prediction[0]))
