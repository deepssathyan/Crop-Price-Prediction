import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import PolynomialFeatures

import pickle

crop_name = 'Sugarcane'
weather = ['Average', 'Bad', 'Good', 'Great']
month = ['Jan', 'Feb', 'Mar', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']

data = pd.read_csv('data_set.csv')
data = data[['month', 'climate', 'demand', 'price']]

to_predict = 'price'

X = np.array(data.drop(to_predict, axis=1))
y = np.array(data[to_predict])

x_train, x_test, y_train, y_test = train_test_split(X, y, test_size=0.3)

poly_regs = PolynomialFeatures(degree=5)
with open("poly_feature.pickle", "wb") as f:
    pickle.dump(poly_regs, f)
linear = LinearRegression()

best = 0
for i in range(100):
    x_train, x_test, y_train, y_test = train_test_split(X, y, test_size=0.2)

    x_poly = poly_regs.fit_transform(x_train)
    linear.fit(x_poly, y_train)

    x_test_poly = poly_regs.fit_transform(x_test)
    acc = linear.score(x_test_poly, y_test)
    print(f'Accuracy : {acc}')

    if acc > best:
        with open("poly_model.pickle", "wb") as f:
            pickle.dump(linear, f)
        best = acc

linear = pickle.load(open('poly_model.pickle', 'rb'))

print(best)
prediction = linear.predict(poly_regs.fit_transform([[1, 1, 0.6]]))
print(round(prediction[0]))
